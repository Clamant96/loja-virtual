package br.com.helpconnect.LojaVirtual;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaVirtualApplicationTests {

	@Test
	void contextLoads() {
	}

}
